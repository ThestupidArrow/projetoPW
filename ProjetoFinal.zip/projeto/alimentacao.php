<?php
    
	include( 'conexaoBD.php' );
    
    $fotoBackground = getFotoBackground();
    $fotoLogo = getFotoLogo();
    $fotoInicio = getFotoInicio();
    $fotoTreino = getFotoTreino();
    $fotoRefeicao = getFotoRefeicao();
    $fotoPurina = getFotoPurina();
    $fotoAbout = getFotoAbout();
    $fotoContactos = getFotoContactos();
    

        
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="paginaInicial.css">
    <title>Train Your Pet</title>
</head>
<body>

    <div class="header">
        <a href="paginaInicial.php">

        <?php
			// logotipo
            foreach ($fotoLogo as $idFotoLogo => $urlFotoLogo):
        ?>

			<div class="img">
				<img src="<?php echo $urlFotoLogo; ?>">
			</div>
        
        <?php endforeach; ?>

         </a><br>
         <h1>Train Your Pet</h1>

         
         <div class="topnav">
            <a href="paginaInicial.php">Inicio</a>
            <a href="dicasTreino.php">Dicas de Treino</a>
            <a class="active" href="alimentacao.php">Sugestões de Alimentação</a>
            <a href="purina.php">Purina &trade;</a>
            <a href="about.php">Sobre nós</a>
            <a href="contactos.php">Contactos</a>
          </div>
    </div>

    
    <br> <br>

    <table style="width:100%">
        <tr>
          <th></th>
          <th>Alimentação</th> 
        </tr>
        <tr>
          <td>
            
          <?php
			// Imagem Inicio
            foreach ($fotoRefeicao as $idFotoRefeicao => $urlFotoRefeicao):
        ?>

			<div class="img">
				<img src=<?php echo $urlFotoRefeicao; ?>  width="450px">
			</div>
        
        <?php endforeach; ?> 
        
        </td>
          <td>
              <li>
                O seu cachorro pode parecer pequeno, mas tem que crescer muito num curto período de tempo!
                Em apenas 12 meses (até 24 meses nas raças maiores) irá crescer e tornar-se um cão adulto.
              </li>
              <br>
              <li>
                <b>Que ração dar aos cachorros.</b> Rações especialmente formuladas para cachorros são os alimentos ideais para o novo membro da
                família porque são completas e equilibradas, o que significa que contêm tudo o que o seu cachorro necessita para o ajudar a crescer saudável.
              </li>
              <br>
              <li>
               <b> Na escolha do melhor alimento para cachorro deve estar atento a:</b>
               <ul>
               <li>Alimento com elevado teor calórico;</li>
               <li>Proteína extra;</li>
               <li>Nutrientes essenciais;</li>
               <li>Croquetes mais pequenos.</li>
              </ul>
            </li>
            
            <li>
               <b>Que quantidade de ração deve dar ao seu cachorro?</b><br>
                Muitas vezes, os cachorros têm mais olhos do que barriga! Para conseguir o equilíbrio certo do que ele necessita e evitar dar-lhe
                comida em excesso, dê-lhe pequenas doses de ração para cachorro com frequência. 
                A quantidade correta depende da idade, tamanho estimado em adulto e de alguma indicação específica 
                que receba do seu médico veterinário.
            </li>
            <br>
            <li>
                <b>Número de refeições que um cachorro deve fazer por dia:</b><br>
                Desde que começa a ingerir alimentos sólidos até ao desmame (normalmente, aos dois meses): 4-6 refeições por dia
                <ul>
                    <li>Entre os dois e os três meses: 4 refeições por dia;</li>
                    <li>Entre os quatro e os seis meses: 2-3 refeições por dia;</li>
                    <li>Mais de seis meses: 2 refeições por dia (dependendo da raça);</li>
                    <li>Evite dar ração em excesso ao seu cachorro porque pode perturbar a sua digestão, além de poder colocar pressão
                     sobre o seu esqueleto caso ele ganhe muito peso num curto período de tempo. Não é bom para a saúde do seu cachorro 
                     comer demasiado, pelo que deve ter cuidado no planeamento das suas refeições.</li>
                </ul>
            </li>

           <br>
            <br> <a href="dicasTreino.php"><button>Página Anterior</button></a>  <a href="purina.php"><button>Próxima Página</button></a>
          </td>
        </tr>
      </table>
</body>
</html>