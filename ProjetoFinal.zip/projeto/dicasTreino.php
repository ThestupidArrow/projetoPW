<?php
    
	include( 'conexaoBD.php' );
    
    $fotoBackground = getFotoBackground();
    $fotoLogo = getFotoLogo();
    $fotoInicio = getFotoInicio();
    $fotoTreino = getFotoTreino();
    $fotoRefeicao = getFotoRefeicao();
    $fotoPurina = getFotoPurina();
    $fotoAbout = getFotoAbout();
    $fotoContactos = getFotoContactos();
    

        
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="paginaInicial.css">
    <title>Train Your Pet</title>
</head>
<body>

    <div class="header">
        <a href="paginaInicial.php">
      

        <?php
			// logotipo
            foreach ($fotoLogo as $idFotoLogo => $urlFotoLogo):
        ?>

			<div class="img">
				<img src="<?php echo $urlFotoLogo; ?>">
			</div>
        
        <?php endforeach; ?>
            </a><br>
         <h1>Train Your Pet</h1>

         <div class="topnav">
            <a href="paginaInicial.php">Inicio</a>
            <a class="active" href="dicasTreino.php">Dicas de Treino</a>
            <a href="alimentacao.php">Sugestões de Alimentação</a>
            <a href="purina.php">Purina &trade;</a>
            <a href="about.php">Sobre nós</a>
            <a href="contactos.php">Contactos</a>
          </div>
    </div>

    
    <br> <br>

    <table style="width:100%">
        <tr>
          <th></th>
          <th>Dicas de Treino</th> 
        </tr>
        <tr>
          <td>

          <?php
			// Imagem Inicio
            foreach ($fotoTreino as $idFotoTreino => $urlFotoTreino):
        ?>

			<div class="img">
				<img src=<?php echo $urlFotoTreino; ?>  width="450px">
			</div>
        
        <?php endforeach; ?>
            </td>

          <td>
            <li>
              <b>Ser consistente.</b> Consistência é chave para qualquer tipo de treino de obediência. 
              Cada vez que o seu cachorro tiver um comportamento desejável (mesmo que não seja durante uma sessão de treino), 
              recompense-o com entusiasmo, fazendo-lhe elogios ou dando-lhe um snack.
            </li>
            <br>
            <li>
                <b>Redirecionar comportamento inapropriado.</b> Chame a atenção do seu cachorro, quando ele fizer algo inapropriado.
                Pode usar a palavra “não”. Quando o seu cachorro olhar para si, dê-lhe uma alternativa de comportamento aceitável. 
                Por exemplo, se apanhar o seu cachorro a roer um sapato, chame a sua atenção e dê-lhe um snack
                ou um brinquedo de roer como alternativa.
            </li>
            <br>
            <li>
                <b>Elogie os bons comportamentos.</b> Quando o seu cachorro mudar a sua atenção para um brinquedo de roer, elogie o seu comportamento. 
                Utilize um clicker, use um tom de voz entusiasta e diga “lindo!”. Recompense-o com mimos tranquilos ou com um snack, se apropriado.
                Quer esteja numa sessão de treino ou não, elogie sempre o seu cachorro por um bom comportamento.
            </li>
            <br>
            <li>
                <b>Utilize snacks.</b> É boa ideia começar o treino do seu cachorro com snacks para recompensar o seu comportamento.
                Ao longo do tempo, vá reduzindo a quantidade de snacks e aumente a quantidade de elogios verbais e físicos como recompensa.
                Isto fará o seu cachorro querer comportar-se bem apenas para receber um mimo ou um elogio,
                em vez de apenas se portar bem quando lhe prometer um snack.
            </li>
            <br>
            <li>
                <b>Termine com uma nota positiva.</b> Se o seu cachorro não conseguiu dominar o comando “Fica” durante uma sessão de treino, 
                volte a um comando que ele conheça, como “senta”. Quando ele se sentar, dê-lhe uma recompensa e muitos elogios.
                Terminar o treino de forma positiva mantém o seu cachorro entusiasmado pela sua próxima sessão de treino, em vez de o desencorajar.
            </li>

            <br>
            <br> <a href="paginaInicial.php"><button>Página Anterior</button></a>  <a href="alimentacao.php"><button>Próxima Página</button></a>
        </td>
        </tr>
      </table>
</body>
</html>