CREATE TABLE IF NOT EXISTS `fotobackground` (
  `id` varchar(25) NOT NULL,
  `url` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB CHARSET=utf8;

INSERT INTO `fotoBackground` (`id`, `url` ) VALUES
('1', 'https://trainyourpet.000webhostapp.com/imagens/background.jpg' );



CREATE TABLE IF NOT EXISTS `fotoLogo` (
  `id` varchar(25) NOT NULL,
  `url` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB CHARSET=utf8;

INSERT INTO `fotoLogo` (`id`, `url` ) VALUES
('1', 'https://trainyourpet.000webhostapp.com/imagens/TrainYourPetLogo.png' );




CREATE TABLE IF NOT EXISTS `fotoInicio` (
  `id` varchar(25) NOT NULL,
  `url` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB CHARSET=utf8;

INSERT INTO `fotoInicio` (`id`, `url` ) VALUES
('3', 'https://trainyourpet.000webhostapp.com/imagens/caoInicio.jpg');


CREATE TABLE IF NOT EXISTS `fotoTreino` (
  `id` varchar(25) NOT NULL,
  `url` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB CHARSET=utf8;

INSERT INTO `fotoTreino` (`id`, `url` ) VALUES
('4', 'https://trainyourpet.000webhostapp.com/imagens/caoTreino.jpg');




CREATE TABLE IF NOT EXISTS `fotoRefeicao` (
  `id` varchar(25) NOT NULL,
  `url` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB CHARSET=utf8;

INSERT INTO `fotoRefeicao` (`id`, `url` ) VALUES
('5', 'https://trainyourpet.000webhostapp.com/imagens/RefeicaoCachorro.jpg' );




CREATE TABLE IF NOT EXISTS `fotoPurina` (
  `id` varchar(25) NOT NULL,
  `url` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB CHARSET=utf8;

INSERT INTO `fotoPurina` (`id`, `url` ) VALUES
('6', 'https://trainyourpet.000webhostapp.com/imagens/purina.jpg' );




CREATE TABLE IF NOT EXISTS `fotoAbout` (
  `id` varchar(25) NOT NULL,
  `url` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB CHARSET=utf8;

INSERT INTO `fotoAbout` (`id`, `url` ) VALUES
('7', 'https://trainyourpet.000webhostapp.com/imagens/caoAbout.jpeg' );




CREATE TABLE IF NOT EXISTS `fotoContactos` (
  `id` varchar(25) NOT NULL,
  `url` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB CHARSET=utf8;

INSERT INTO `fotoContactos` (`id`, `url` ) VALUES
('8', 'https://trainyourpet.000webhostapp.com/imagens/Contactos.png' );