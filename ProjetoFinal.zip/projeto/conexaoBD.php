<?php 
	
  function estabelerConexao()
{
     // Deviam estar num ficheiro de configuração
    $hostname = "localhost";
    $databasename = "imagenstyp";
    $username = "PW_User";
    $password = "1234";
    
    try {
        $conexao = new PDO("mysql:host=$hostname;dbname=$databasename;charset=utf8mb4",
                       $username, $password);
    }
    catch (\PDOException $e) {
        echo $e->getMessage();
    }

    return $conexao;

}
function getFotoBackground() 
{
    $conexao = estabelerConexao();

    $stmt = $conexao->query('SELECT * FROM fotobackground');

    $fotoBackground = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

    return $fotoBackground;
}



function getFotoLogo() 
{
    $conexao = estabelerConexao();

    $stmt = $conexao->query('SELECT * FROM fotoLogo');

    $fotoLogo = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

    return $fotoLogo;
}



function getFotoInicio() 
{
    $conexao = estabelerConexao();

    $stmt = $conexao->query('SELECT * FROM fotoInicio');

    $fotoInicio = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

    return $fotoInicio;
}


function getFotoTreino() 
{
    $conexao = estabelerConexao();

    $stmt = $conexao->query('SELECT * FROM fotoTreino');

    $fotoTreino = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

    return $fotoTreino;
}

function getFotoRefeicao()
{
    $conexao = estabelerConexao();

    $stmt = $conexao->query('SELECT * FROM fotoRefeicao');

    $fotoRefeicao = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

    return $fotoRefeicao;
}


function getFotoPurina() 
{
    $conexao = estabelerConexao();

    $stmt = $conexao->query('SELECT * FROM fotoPurina');

    $fotoPurina = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

    return $fotoPurina;
}


function getFotoAbout() 
{
    $conexao = estabelerConexao();

    $stmt = $conexao->query('SELECT * FROM fotoAbout');

    $fotoAbout = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

    return $fotoAbout;
}


function getFotoContactos() 
{
    $conexao = estabelerConexao();

    $stmt = $conexao->query('SELECT * FROM fotoContactos');

    $fotoContactos = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

    return $fotoContactos;
}

 ?>