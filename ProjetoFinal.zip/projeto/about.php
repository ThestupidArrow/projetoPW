<?php
    
	include( 'conexaoBD.php' );
    
    $fotoBackground = getFotoBackground();
    $fotoLogo = getFotoLogo();
    $fotoInicio = getFotoInicio();
    $fotoTreino = getFotoTreino();
    $fotoRefeicao = getFotoRefeicao();
    $fotoPurina = getFotoPurina();
    $fotoAbout = getFotoAbout();
    $fotoContactos = getFotoContactos();
    
        
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="paginaInicial.css">
    <title>Train Your Pet</title>
</head>
<body>

    <div class="header">
        <a href="paginaInicial.php">

        <?php
			// logotipo
            foreach ($fotoLogo as $idFotoLogo => $urlFotoLogo):
        ?>

			<div class="img">
				<img src="<?php echo $urlFotoLogo; ?>">
			</div>
        
        <?php endforeach; ?>

         </a><br>
         <h1>Train Your Pet</h1>

         
         <div class="topnav">
            <a href="paginaInicial.php">Inicio</a>
            <a href="dicasTreino.php">Dicas de Treino</a>
            <a href="alimentacao.php">Sugestões de Alimentação</a>
            <a href="purina.php">Purina &trade;</a>
            <a class="active" href="about.php">Sobre nós</a>
            <a href="contactos.php">Contactos</a>
          </div>
    </div>

    
    <br> <br>

    <table style="width:100%">
        <tr>
          <th></th>
          <th>Sobre Nós</th> 
        </tr>
        <tr>
          <td>
            
          <?php
			// Imagem About
            foreach ($fotoAbout as $idFotoAbout => $urlFotoAbout):
        ?>

			<div class="img">
				<img src=<?php echo $urlFotoAbout; ?>  width="450px">
			</div>
        
        <?php endforeach; ?>
        
        </td>
          <td>

            <p>Decidi criar este website, como forma de complementar e divulgar a aplicação que desenvolvi para ajudar recentes donos de cachorros
              a aprender como os treinar e tratar. Como acréscimo, há informações no website que não constam na aplicação, e que é 
              recomendado ao utilizador ler e aprender com a mesma.</p>
            <p>A ideia surgiu devido a eu ter adotado um cachorro recentemente, e me encontrar constantemente a fazer pesquisas de como 
              o treinar, o que é normal ele comer e o que fazer caso coma algo que não deva, entre outras das várias questões que se tem quando
              se adota um animal.</p>
            <p>Caso tenha interesse em usar a aplicação para treinar o seu cachorro, e obter descontos em alguns
              produtos da Purina &trade;, pode fazer o download da mesma <a href="https://github.com/ThestupidArrow/trainyourpet" target="_blank">aqui</a>. </p>
            <br>
            <br> <a href="purina.php"><button>Página Anterior</button></a> <a href="contactos.php"><button>Próxima Página</button></a>
          </td>
        </tr>
      </table>

</body>
</html>