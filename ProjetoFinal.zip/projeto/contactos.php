<?php
    
	include( 'conexaoBD.php' );
    
    $fotoBackground = getFotoBackground();
    $fotoLogo = getFotoLogo();
    $fotoInicio = getFotoInicio();
    $fotoTreino = getFotoTreino();
    $fotoRefeicao = getFotoRefeicao();
    $fotoPurina = getFotoPurina();
    $fotoAbout = getFotoAbout();
    $fotoContactos = getFotoContactos();
    

        
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="paginaInicial.css">
    <title>Train Your Pet</title>
</head>
<body>

    <div class="header">
        <a href="paginaInicial.php">

        <?php
			// logotipo
            foreach ($fotoLogo as $idFotoLogo => $urlFotoLogo):
        ?>

			<div class="img">
				<img src="<?php echo $urlFotoLogo; ?>">
			</div>
        
        <?php endforeach; ?>

         </a><br>
         <h1>Train Your Pet</h1>

         
         <div class="topnav">
            <a href="paginaInicial.php">Inicio</a>
            <a href="dicasTreino.php">Dicas de Treino</a>
            <a href="alimentacao.php">Sugestões de Alimentação</a>
            <a href="purina.php">Purina &trade;</a>
            <a href="about.php">Sobre nós</a>
            <a class="active" href="contactos.php">Contactos</a>
          </div>
    </div>

    
    <br> <br>

    <table style="width:100%">
        <tr>
          <th></th>
          <th>Contactos</th> 
        </tr>
        <tr>
          <td>

            <?php
			// Imagem Inicio
            foreach ($fotoContactos as $idFotoContactos => $urlFotoContactos):
        ?>

			<div class="img">
				<img src=<?php echo $urlFotoContactos; ?>  width="400px">
			</div>
        
        <?php endforeach; ?>
          
          </td>
          <td>
            <p>Caso tenha alguma dúvida, talvez acerca do funcionamento da aplicação na secção "
            <a href="about.php" target="_blank">Sobre Nós</a>" ou sugestões para melhorar a informação transmitida no website, 
            sinta-se livre de nos contactar através dos meios apresentados abaixo.</p>
            <br>
            <li><b>Email : </b>190100209@esg.ipsantarem.pt</li>
            <br>
            <li><b>Telefone : </b> 960 314 331</li>
            
            <br>
            <br> <a href="about.php"><button>Página Anterior</button></a>
          </td>
        </tr>
      
      </table>
</body>
</html>