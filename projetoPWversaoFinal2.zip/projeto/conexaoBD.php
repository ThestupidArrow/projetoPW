<?php 
	
  function estabelerConexao()
{
    
    $hostname = "localhost";
    $databasename = "imagenstyp";
    $username = "PW_User";
    $password = "1234";
    
    try {
        $conexao = new PDO("mysql:host=$hostname;dbname=$databasename;charset=utf8mb4",
                       $username, $password);
    }
    catch (\PDOException $e) {
        echo $e->getMessage();
    }

    return $conexao;

}
function getFotoBackground() 
{
    $conexao = estabelerConexao();

    $stmt = $conexao->query('SELECT * FROM fotobackground');

    $fotoBackground = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

    return $fotoBackground;
}



function getFotoLogo() 
{
    $conexao = estabelerConexao();

    $stmt = $conexao->query('SELECT * FROM fotoLogo');

    $fotoLogo = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

    return $fotoLogo;
}



function getFotoInicio() 
{
    $conexao = estabelerConexao();

    $stmt = $conexao->query('SELECT * FROM fotoInicio');

    $fotoInicio = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

    return $fotoInicio;
}


function getFotoTreino() 
{
    $conexao = estabelerConexao();

    $stmt = $conexao->query('SELECT * FROM fotoTreino');

    $fotoTreino = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

    return $fotoTreino;
}

function getFotoRefeicao()
{
    $conexao = estabelerConexao();

    $stmt = $conexao->query('SELECT * FROM fotoRefeicao');

    $fotoRefeicao = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

    return $fotoRefeicao;
}


function getFotoPurina() 
{
    $conexao = estabelerConexao();

    $stmt = $conexao->query('SELECT * FROM fotoPurina');

    $fotoPurina = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

    return $fotoPurina;
}


function getFotoAbout() 
{
    $conexao = estabelerConexao();

    $stmt = $conexao->query('SELECT * FROM fotoAbout');

    $fotoAbout = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

    return $fotoAbout;
}


function getFotoContactos() 
{
    $conexao = estabelerConexao();

    $stmt = $conexao->query('SELECT * FROM fotoContactos');

    $fotoContactos = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

    return $fotoContactos;
}

function getFotoFriskies() 
{
    $conexao = estabelerConexao();

    $stmt = $conexao->query('SELECT * FROM fotoFriskies');

    $fotoFriskies = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

    return $fotoFriskies;
}


function getFotoFriskiesRacao() 
{
    $conexao = estabelerConexao();

    $stmt = $conexao->query('SELECT * FROM fotoFriskiesRacao');

    $fotoFriskiesRacao = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

    return $fotoFriskiesRacao;
}



function getFotoFriskiesBiscoito() 
{
    $conexao = estabelerConexao();

    $stmt = $conexao->query('SELECT * FROM fotoFriskiesBiscoito');

    $fotoFriskiesBiscoito = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

    return $fotoFriskiesBiscoito;
}



function getFotoFriskiesHumido() 
{
    $conexao = estabelerConexao();

    $stmt = $conexao->query('SELECT * FROM fotoFriskiesHumido');

    $fotoFriskiesHumido = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

    return $fotoFriskiesHumido;
}


function getFotoProPlan() 
{
    $conexao = estabelerConexao();

    $stmt = $conexao->query('SELECT * FROM fotoProPlan');

    $fotoProPlan = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

    return $fotoProPlan;
}


function getFotoProPlanRacao() 
{
    $conexao = estabelerConexao();

    $stmt = $conexao->query('SELECT * FROM fotoProPlanRacao');

    $fotoProPlanRacao = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

    return $fotoProPlanRacao;
}


function getFotoProPlanBiscoito() 
{
    $conexao = estabelerConexao();

    $stmt = $conexao->query('SELECT * FROM fotoProPlanBiscoito');

    $fotoProPlanBiscoito = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

    return $fotoProPlanBiscoito;
}


function getFotoProPlanSnack() 
{
    $conexao = estabelerConexao();

    $stmt = $conexao->query('SELECT * FROM fotoProPlanSnack');

    $fotoProPlanSnack = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

    return $fotoProPlanSnack;
}

function getFotoOne() 
{
    $conexao = estabelerConexao();

    $stmt = $conexao->query('SELECT * FROM fotoOne');

    $fotoOne = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

    return $fotoOne;
}

function getFotoOneRacao() 
{
    $conexao = estabelerConexao();

    $stmt = $conexao->query('SELECT * FROM fotoOneRacao');

    $fotoOneRacao = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

    return $fotoOneRacao;
}

function getFotoOneSnack() 
{
    $conexao = estabelerConexao();

    $stmt = $conexao->query('SELECT * FROM fotoOneSnack');

    $fotoOneSnack = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

    return $fotoOneSnack;
}


function getFotoOneHumido() 
{
    $conexao = estabelerConexao();

    $stmt = $conexao->query('SELECT * FROM fotoOneHumido');

    $fotoOneHumido = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

    return $fotoOneHumido;
}

 ?>