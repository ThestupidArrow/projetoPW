<?php
    
	include( 'conexaoBD.php' );
    
    $fotoBackground = getFotoBackground();
    $fotoLogo = getFotoLogo();
    $fotoInicio = getFotoInicio();
    $fotoTreino = getFotoTreino();
    $fotoRefeicao = getFotoRefeicao();
    $fotoPurina = getFotoPurina();
    $fotoAbout = getFotoAbout();
    $fotoContactos = getFotoContactos();
    $fotoFriskies = getFotoFriskies();
    $fotoFriskiesRacao = getFotoFriskiesRacao();
    $fotoFriskiesBiscoito = getFotoFriskiesBiscoito();
    $fotoFriskiesHumido = getFotoFriskiesHumido();
    $fotoProPlan = getFotoProPlan();
    $fotoProPlanRacao = getFotoProPlanRacao();
    $fotoProPlanBiscoito = getFotoProPlanBiscoito();
    $fotoProPlanSnack = getFotoProPlanSnack();
    $fotoOne = getFotoOne();
    $fotoOneRacao = getFotoOneRacao();
    $fotoOneSnack = getFotoOneSnack();
    $fotoOneHumido = getFotoOneHumido();
        
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="paginaInicial.css">
    <title>Train Your Pet</title>
</head>
<body>

    <div class="header">
        <a href="paginaInicial.php">
      
        <?php
			// logotipo
            foreach ($fotoLogo as $idFotoLogo => $urlFotoLogo):
        ?>

			<div class="img">
				<img src="<?php echo $urlFotoLogo; ?>">
			</div>
        
        <?php endforeach; ?>
            </a><br>
         <h1>Train Your Pet</h1>

         <div class="topnav">
            <a href="paginaInicial.php">Inicio</a>
            <a href="dicasTreino.php">Dicas de Treino</a>
            <a href="alimentacao.php">Sugestões de Alimentação</a>
            <a href="purina.php">Purina &trade;</a>
            <a class="active" href="marcas.php">Algumas das Marcas</a>
            <a href="about.php">Sobre nós</a>
            <a href="contactos.php">Contactos</a>
          </div>
    </div>

    <br> <br>

    <table style="width:100%">
        <tr>
        <th></th>
        <th></th>
          <th>Algumas Marcas</th> 
          <th></th>
          <th></th>
          
        </tr>
        <tr>
          <td>

          <!-- Frieskies-->
          <?php
			
            foreach ($fotoFriskies as $idFotoFriskies=> $urlFotoFriskies):
        ?>
			<div class="img">
                <img src=<?php echo $urlFotoFriskies; ?>  width="300px">
			</div>
        <?php endforeach; ?>

            </td>

        <td>
            Ração Friskies Junior
        <?php
			
            foreach ($fotoFriskiesRacao as $idFotoFriskiesRacao => $urlFotoFriskiesRacao):
        ?>
			<div class="img">
				<img src=<?php echo $urlFotoFriskiesRacao; ?>  width="150px">
			</div>
        <?php endforeach; ?>
            </td>
         
            <td>
        Biscoitos Friskies Junior
        <?php
			
            foreach ($fotoFriskiesBiscoito as $idFotoFriskiesBiscoito=> $urlFotoFriskiesBiscoito):
        ?>
			<div class="img">
				<img src=<?php echo $urlFotoFriskiesBiscoito; ?>  width="150px">
			</div>
        <?php endforeach; ?>

            </td> 
        
            <td>
        Comida Húmida Friskies Junior
        <?php
		
            foreach ($fotoFriskiesHumido as $idFotoFriskiesHumido => $urlFotoFriskiesHumido):
        ?>
			<div class="img">
				<img src=<?php echo $urlFotoFriskiesHumido; ?>  width="150px">
			</div>
        <?php endforeach; ?>

            </td>
        
        </tr>
      </table>



      <!-- ProPlan-->

      <table style="width:100%">
        
        <tr>
          <td>
          <?php
			
            foreach ($fotoProPlan as $idFotoProPlan => $urlFotoProPlan):
        ?>
			<div class="img">
				<img src=<?php echo $urlFotoProPlan; ?>  width="300px">
			</div>
        <?php endforeach; ?>

            </td>

        <td>
            Ração ProPlan Junior
        <?php
			
            foreach ($fotoProPlanRacao as $idFotoProPlanRacao => $urlFotoProPlanRacao):
        ?>
			<div class="img">
				<img src=<?php echo $urlFotoProPlanRacao; ?>  width="150px">
			</div>
        <?php endforeach; ?>
            </td>
         
            <td>
        Biscoitos ProPlan Junior
        <?php
			
            foreach ($fotoProPlanBiscoito as $idFotoProPlanBiscoito=> $urlFotoProPlanBiscoito):
        ?>
			<div class="img">
				<img src=<?php echo $urlFotoProPlanBiscoito; ?>  width="150px">
			</div>
        <?php endforeach; ?>

            </td> 
        
            <td>
        Snacks ProPlan Junior
        <?php
			
            foreach ($fotoProPlanSnack as $idFotoProPlanSnack => $urlFotoProPlanSnack):
        ?>
			<div class="img">
				<img src=<?php echo $urlFotoProPlanSnack; ?>  width="150px">
			</div>
        <?php endforeach; ?>

            </td>
            

            <!-- One-->

            <table style="width:100%">
       
        <tr>
          <td>
          <?php
			
            foreach ($fotoOne as $idFotoOne => $urlFotoOne):
        ?>
			<div class="img">
				<img src=<?php echo $urlFotoOne; ?>  width="300px">
			</div>
        <?php endforeach; ?>

            </td>

        <td>
            Ração One Junior
        <?php
			
            foreach ($fotoOneRacao as $idFotoOneRacao => $urlFotoOneRacao):
        ?>
			<div class="img">
				<img src=<?php echo $urlFotoOneRacao; ?>  width="150px">
			</div>
        <?php endforeach; ?>
            </td>
         
            <td>
        Snacks One Junior
        <?php
			
            foreach ($fotoOneSnack as $idFotoOneSnack => $urlFotoOneSnack):
        ?>
			<div class="img">
				<img src=<?php echo $urlFotoOneSnack; ?>  width="150px">
			</div>
        <?php endforeach; ?>

            </td> 
        
            <td>
        Comida Húmida One Junior
        <?php
			
            foreach ($fotoOneHumido as $idFotoOneHumidoo => $urlFotoOneHumido):
        ?>
			<div class="img">
				<img src=<?php echo $urlFotoOneHumido; ?>  width="150px">
			</div>
        <?php endforeach; ?>

            
        
            <br><br><a href="alimentacao.php"><button>Página Anterior</button></a>  <a href="marcas.php"><button>Próxima Página</button></a>
          </td>
        </tr>
      </table>
            
</body>
</html>
