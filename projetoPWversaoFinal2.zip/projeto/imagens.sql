CREATE TABLE IF NOT EXISTS `fotobackground` (
  `id` varchar(25) NOT NULL,
  `url` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB CHARSET=utf8;

INSERT INTO `fotoBackground` (`id`, `url` ) VALUES
('1', 'https://trainyourpet.000webhostapp.com/imgurl/background.jpg' );



CREATE TABLE IF NOT EXISTS `fotoLogo` (
  `id` varchar(25) NOT NULL,
  `url` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB CHARSET=utf8;

INSERT INTO `fotoLogo` (`id`, `url` ) VALUES
('2', 'https://trainyourpet.000webhostapp.com/imgurl/TrainYourPetLogo.png' );




CREATE TABLE IF NOT EXISTS `fotoInicio` (
  `id` varchar(25) NOT NULL,
  `url` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB CHARSET=utf8;

INSERT INTO `fotoInicio` (`id`, `url` ) VALUES
('3', 'https://trainyourpet.000webhostapp.com/imgurl/caoInicio.jpg');


CREATE TABLE IF NOT EXISTS `fotoTreino` (
  `id` varchar(25) NOT NULL,
  `url` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB CHARSET=utf8;

INSERT INTO `fotoTreino` (`id`, `url` ) VALUES
('4', 'https://trainyourpet.000webhostapp.com/imgurl/caoTreino.jpg');




CREATE TABLE IF NOT EXISTS `fotoRefeicao` (
  `id` varchar(25) NOT NULL,
  `url` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB CHARSET=utf8;

INSERT INTO `fotoRefeicao` (`id`, `url` ) VALUES
('5', 'https://trainyourpet.000webhostapp.com/imgurl/RefeicaoCachorro.jpg' );




CREATE TABLE IF NOT EXISTS `fotoPurina` (
  `id` varchar(25) NOT NULL,
  `url` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB CHARSET=utf8;

INSERT INTO `fotoPurina` (`id`, `url` ) VALUES
('6', 'https://trainyourpet.000webhostapp.com/imgurl/purina.jpg' );




CREATE TABLE IF NOT EXISTS `fotoAbout` (
  `id` varchar(25) NOT NULL,
  `url` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB CHARSET=utf8;

INSERT INTO `fotoAbout` (`id`, `url` ) VALUES
('7', 'https://trainyourpet.000webhostapp.com/imgurl/caoAbout.jpeg' );




CREATE TABLE IF NOT EXISTS `fotoContactos` (
  `id` varchar(25) NOT NULL,
  `url` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB CHARSET=utf8;

INSERT INTO `fotoContactos` (`id`, `url` ) VALUES
('8', 'https://trainyourpet.000webhostapp.com/imgurl/Contactos.png' );



CREATE TABLE IF NOT EXISTS `fotoFriskies` (
  `id` varchar(25) NOT NULL,
  `url` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB CHARSET=utf8;

INSERT INTO `fotoFriskies` (`id`, `url` ) VALUES
('9', 'https://trainyourpet.000webhostapp.com/imgurl/logoFriskies.png' );



CREATE TABLE IF NOT EXISTS `fotoFriskiesRacao` (
  `id` varchar(25) NOT NULL,
  `url` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB CHARSET=utf8;

INSERT INTO `fotoFriskiesRacao` (`id`, `url` ) VALUES
('10', 'https://trainyourpet.000webhostapp.com/imgurl/racaoFriskies.png' );



CREATE TABLE IF NOT EXISTS `fotoFriskiesBiscoito` (
  `id` varchar(25) NOT NULL,
  `url` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB CHARSET=utf8;

INSERT INTO `fotoFriskiesBiscoito` (`id`, `url` ) VALUES
('11', 'https://trainyourpet.000webhostapp.com/imgurl/biscoitoFriskies.png' );



CREATE TABLE IF NOT EXISTS `fotoFriskiesHumido` (
  `id` varchar(25) NOT NULL,
  `url` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB CHARSET=utf8;

INSERT INTO `fotoFriskiesHumido` (`id`, `url` ) VALUES
('12', 'https://trainyourpet.000webhostapp.com/imgurl/humidoFriskies.png' );



CREATE TABLE IF NOT EXISTS `fotoProPlan` (
  `id` varchar(25) NOT NULL,
  `url` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB CHARSET=utf8;

INSERT INTO `fotoProPlan` (`id`, `url` ) VALUES
('13', 'https://trainyourpet.000webhostapp.com/imgurl/logoProPlan.png' );



CREATE TABLE IF NOT EXISTS `fotoProPlanRacao` (
  `id` varchar(25) NOT NULL,
  `url` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB CHARSET=utf8;

INSERT INTO `fotoProPlanRacao` (`id`, `url` ) VALUES
('14', 'https://trainyourpet.000webhostapp.com/imgurl/racaoProPlan.png' );



CREATE TABLE IF NOT EXISTS `fotoProPlanBiscoito` (
  `id` varchar(25) NOT NULL,
  `url` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB CHARSET=utf8;

INSERT INTO `fotoProPlanBiscoito` (`id`, `url` ) VALUES
('15', 'https://trainyourpet.000webhostapp.com/imgurl/biscoitoProPlan.png' );



CREATE TABLE IF NOT EXISTS `fotoProPlanSnack` (
  `id` varchar(25) NOT NULL,
  `url` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB CHARSET=utf8;

INSERT INTO `fotoProPlanSnack` (`id`, `url` ) VALUES
('16', 'https://trainyourpet.000webhostapp.com/imgurl/proPlanSnack.png' );


CREATE TABLE IF NOT EXISTS `fotoOne` (
  `id` varchar(25) NOT NULL,
  `url` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB CHARSET=utf8;

INSERT INTO `fotoOne` (`id`, `url` ) VALUES
('17', 'https://trainyourpet.000webhostapp.com/imgurl/logoOne.png' );




CREATE TABLE IF NOT EXISTS `fotoOneRacao` (
  `id` varchar(25) NOT NULL,
  `url` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB CHARSET=utf8;

INSERT INTO `fotoOneRacao` (`id`, `url` ) VALUES
('18', 'https://trainyourpet.000webhostapp.com/imgurl/oneRacao.png' );




CREATE TABLE IF NOT EXISTS `fotoOneSnack` (
  `id` varchar(25) NOT NULL,
  `url` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB CHARSET=utf8;

INSERT INTO `fotoOneSnack` (`id`, `url` ) VALUES
('19', 'https://trainyourpet.000webhostapp.com/imgurl/oneSnacks.png' );





CREATE TABLE IF NOT EXISTS `fotoOneHumido` (
  `id` varchar(25) NOT NULL,
  `url` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB CHARSET=utf8;

INSERT INTO `fotoOneHumido` (`id`, `url` ) VALUES
('20', 'https://trainyourpet.000webhostapp.com/imgurl/humidoOne.png' );