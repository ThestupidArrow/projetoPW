<?php
    
	include( 'conexaoBD.php' );
    
    $fotoBackground = getFotoBackground();
    $fotoLogo = getFotoLogo();
    $fotoInicio = getFotoInicio();
    $fotoTreino = getFotoTreino();
    $fotoRefeicao = getFotoRefeicao();
    $fotoPurina = getFotoPurina();
    $fotoAbout = getFotoAbout();
    $fotoContactos = getFotoContactos();
    

        
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="paginaInicial.css">
    <title>Train Your Pet</title>
</head>
<body>

    <div class="header">
        <a href="paginaInicial.php">

        <?php
			// logotipo
            foreach ($fotoLogo as $idFotoLogo => $urlFotoLogo):
        ?>

			<div class="img">
				<img src="<?php echo $urlFotoLogo; ?>">
			</div>
        
        <?php endforeach; ?>
         
          </a><br>
         <h1>Train Your Pet</h1>

         
         <div class="topnav">
            <a href="paginaInicial.php">Inicio</a>
            <a href="dicasTreino.php">Dicas de Treino</a>
            <a href="alimentacao.php">Sugestões de Alimentação</a>
            <a class="active" href="purina.php">Purina &trade;</a>
            <a href="marcas.php">Algumas das Marcas</a>
            <a href="about.php">Sobre nós</a>
            <a href="contactos.php">Contactos</a>
          </div>
    </div>

    
    <br> <br>

    <table style="width:100%">
        <tr>
          <th></th>
          <th>Purina &trade;</th> 
        </tr>
        <tr>
          <td>
            
          <?php
			// Imagem Inicio
            foreach ($fotoPurina as $idFotoPurina => $urlFotoPurina):
        ?>

			<div class="img">
				<img src=<?php echo $urlFotoPurina; ?>  width="350px">
			</div>
        
        <?php endforeach; ?>
        
        </td>
          <td>
            <p>A Purina &trade; é das marcas mais conhecidas e prestigiadas em Portugal. Sendo uma marca de confiança e escolhida por várias pessoas
              para alimentar e cuidar dos seus animais.</p>
            <li>
              <b>Compromissos da Purina &trade; até 2023 :</b>
              <ul>
              <li>Inovar para melhorar a saúde e bem-estar do seu animal de companhia;</li>
              <li>Promover a transparência em todo o nosso portfolio de produtos;</li>
              <li>Remover corantes artificiais dos nossos produtos;</li>
              <li>Ajudar a reduzir o risco de obesidade em pets;</li>
              <li>Promover a adoção de pets através de parcerias;</li>
              <li>Promover a presença de pets no local de trabalho;</li>
              <li>Promover programas com crianças sobre como ser um tutor responsável;</li>
              <li>Criar oportunidades de trabalho na Purina &trade; para jovens em toda a Europa;</li>
              <li>Melhorar a performance ambiental das embalagens de produtos Purina &trade;;</li>
              <li>Implementar fontes de fornecimento sustentáveis.</li>
              </ul>
            </li>
            <p><b>Para informações mais detalhadas, acerca da Purina &trade;, da sua missão e dos seus produtos,
               <a href="https://www.purina.pt/" target="_blank">recomendo a visita ao website deles</a>.</b></p>
            <br>
            <br><a href="alimentacao.php"><button>Página Anterior</button></a>  <a href="marcas.php"><button>Próxima Página</button></a>
          </td>
        </tr>
      </table>
</body>
</html>