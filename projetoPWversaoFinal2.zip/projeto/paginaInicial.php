<?php
    
	include( 'conexaoBD.php' );
    
    $fotoBackground = getFotoBackground();
    $fotoLogo = getFotoLogo();
    $fotoInicio = getFotoInicio();
    $fotoTreino = getFotoTreino();
    $fotoRefeicao = getFotoRefeicao();
    $fotoPurina = getFotoPurina();
    $fotoAbout = getFotoAbout();
    $fotoContactos = getFotoContactos();
    

        
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="paginaInicial.css"> 
    <title>Train Your Pet</title>
</head>
<body>
			
    <div class="header">
        <a href="paginaInicial.php">

        <?php
			// logotipo
            foreach ($fotoLogo as $idFotoLogo => $urlFotoLogo):
        ?>

			<div class="img">
				<img src="<?php echo $urlFotoLogo; ?>">
			</div>
        
        <?php endforeach; ?>

         </a><br>
         <h1>Train Your Pet</h1>

         
         <div class="topnav">
            <a class="active" href="paginaInicial.php">Inicio</a>
            <a href="dicasTreino.php">Dicas de Treino</a>
            <a href="alimentacao.php">Sugestões de Alimentação</a>
            <a href="purina.php">Purina &trade;</a>
            <a href="marcas.php">Algumas das Marcas</a>
            <a href="about.php">Sobre nós</a>
            <a href="contactos.php">Contactos</a>
          </div>
    </div>

    <br> <br>

    <table style="width:100%">
        <tr>
          <th></th>
          <th>Inicio</th> 
        </tr>
        <tr>
          <td>
        <?php
			// Imagem Inicio
            foreach ($fotoInicio as $idFotoInicio => $urlFotoInicio):
        ?>

			<div class="img">
				<img src=<?php echo $urlFotoInicio; ?>  width="450px">
			</div>
        
        <?php endforeach; ?>


            </td>
          <td>
            <p>Neste website poderá encontrar algumas dicas sobre como treinar o seu cachorro, nomeadamente, treinar os comportamos.</p>
            <p>Tal como os cuidados a ter com a alimentação do seu animal.</p>
            <p>Poderá também ler algumas informações básicas acerca da Purina &trade;, e os seus produtos.</p>
            <p>Temos também disponivel uma aplicação móvel para download, em parceria com a Purina &trade; que serve de auxilio para treino do seu
              animal, e onde poderá receber códigos promocionais para produtos Purina &trade;.</p>
            </p>
            <br>
            <br> <a href="dicasTreino.php"><button>Próxima Página</button></a>
          </td>
        </tr>
      </table>

</body>
</html>